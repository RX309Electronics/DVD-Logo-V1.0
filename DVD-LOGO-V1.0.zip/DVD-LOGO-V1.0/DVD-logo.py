#import modules and init pygame
from random import randint
import pygame
pygame.init()

#Make sure to define the running variable to be true or else it will close the window and stop running 
running = True

#Pygame Window settings
Window_SIZE = width, height = 800, 600  # Resolution. (4:3)!
BG_COLOR = (0, 0, 0)  # Background color in RGB
screen = pygame.display.set_mode(Window_SIZE)
fullscreen = False  # Fullscreen
if fullscreen:
    DISPLAYSURF = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    pygame.mouse.set_visible(False)

#Configure The Logo size and image
dvd_logo = pygame.image.load('DVD-LOGO.png')
dvd_logo = pygame.transform.scale(dvd_logo, (100, 100))
img_size = dvd_logo.get_rect().size

#Configure the clock variable
clock = pygame.time.Clock()

#Set the name of the window
pygame.display.set_caption('DVD Corner')

#Set X and y variables
x = randint(50, width-60)
y = randint(50, height-60)
x_speed = 2.5
y_speed = 2.5

#Define the move function
def move(x, y):
    screen.blit(dvd_logo, (x, y))

#The main logic that has to run in a loop untiull the window is closed
while running == True:
    screen.fill(BG_COLOR)
    if (x + img_size[0] >= width) or (x <= 0):
        x_speed = -x_speed
    if (y + img_size[1] >= height) or (y <= 0):
        y_speed = -y_speed
    x += x_speed   
    y += y_speed   
    move(x, y)     
    pygame.display.update() #Constantly update the display frames
    clock.tick(60)  #Define the clock speed of the game

    #Add a close function so you can cose the window and the game also stops
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
pygame.quit()